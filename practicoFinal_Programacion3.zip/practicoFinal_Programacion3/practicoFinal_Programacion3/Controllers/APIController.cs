﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using practicoFinal_Programacion3.DATA;
using practicoFinal_Programacion3.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;


namespace practicoFinal_Programacion3.Controllers
{
    [ApiController]
    [Route("api")]
    public class APIController : Controller
    {
        private readonly AppDBcontext _context;

        public APIController(AppDBcontext contex)
        {
            _context = contex;
        }

        [HttpGet("ListarMonedas")]
        public IActionResult ListarMonedas()
        {
            var monedas = _context.Monedas.Select(e => new
            {
                e.Id,
                e.Abreviatura
            }).ToList();
            return Ok(monedas);
        }

        [HttpGet("ListarTransacciones")]
        public IActionResult ListarTransacciones()
        {
            var transacciones = _context.Transacciones.Select(e => new
            {
                e.moneda.Nombre,
                Cantidad = Math.Abs(e.Cantidad),
                e.Cotizacion,
                e.Fecha,
                MontoTotal = Math.Abs(e.Cantidad) * e.Cotizacion,
                e.Operacion
            }).ToList();
            return Ok(transacciones);
        }

        [HttpGet("EstadoActual")]
        public async Task<IActionResult> EstadoActual()
        {
            List<Moneda> monedas = _context.Monedas.Include(e => e.transacciones).ToList();
            List<ViewModelMonedas> primeraListaMonedas = new List<ViewModelMonedas>();
            using HttpClient client = new HttpClient();
            double cantidadPesosTotal = 0;

            foreach (var moneda in monedas)
            {
            double cantidad = moneda.transacciones.Sum(e => e.Cantidad);

                if (cantidad > 0)
                {
                    try
                    {
                        string url = $"https://criptoya.com/api/binancep2p/{moneda.Abreviatura}/ARS/0.1";
                        HttpResponseMessage response = await client.GetAsync(url);
                        response.EnsureSuccessStatusCode();
                        string json = await response.Content.ReadAsStringAsync();
                        var askValue = System.Text.Json.JsonDocument.Parse(json).RootElement.GetProperty("ask").GetDouble();
                        double totalPesos = askValue * cantidad;
                        var objetoMoneda = new ViewModelMonedas
                        {
                            MonedaNombre = moneda.Abreviatura,
                            Saldo = totalPesos,
                        };
                        cantidadPesosTotal += totalPesos;
                        primeraListaMonedas.Add(objetoMoneda);
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
            }
            var ListaMonedas = primeraListaMonedas.Select(item => new ViewModelMonedas
                 {
                     MonedaNombre = item.MonedaNombre,
                     Saldo = item.Saldo,
                     SaldoTotalPesos = cantidadPesosTotal
                 }).ToList();

            return Ok(ListaMonedas);
        }

        [HttpPost("CrearTransaction")]
        public IActionResult CrearTransaction([FromBody] Transaccion transaccion)
        {
            var fechaUtc = transaccion.Fecha.UtcDateTime; 
            var zonaArgentina = TimeZoneInfo.FindSystemTimeZoneById("Argentina Standard Time");
            var fechaLocal = TimeZoneInfo.ConvertTimeFromUtc(fechaUtc, zonaArgentina);
            if (transaccion.Operacion == "Compra")
            {
                if (transaccion.Cantidad > 0 && double.TryParse(transaccion.Cantidad.ToString(), out double numero))
                {
                    var nuevaTransaccion = new Transaccion
                    {
                        MonedaId = transaccion.MonedaId,
                        Cantidad = transaccion.Cantidad,
                        Cotizacion = transaccion.Cotizacion,
                        Fecha = fechaLocal,
                        Operacion = transaccion.Operacion
                    };
                    _context.Transacciones.Add(nuevaTransaccion);
                    _context.SaveChanges();
                    return Ok(nuevaTransaccion);
                }
                else
                    return BadRequest(new { mensaje = "datos ingresados incorrectos" });
            }
            else
            {
                double cantidadNegativa = Math.Abs(transaccion.Cantidad) * -1;
                List<Moneda> monedas = _context.Monedas.Include(e => e.transacciones).ToList();
                List<ViewModelMonedas> lista = new List<ViewModelMonedas>();
                foreach (var item in monedas)
                {
                    var objMonedas = new ViewModelMonedas
                    {
                        IdMoneda = item.Id,
                        MonedaNombre = item.Nombre,
                        Saldo = item.transacciones.Sum(e => e.Cantidad)
                    };
                    lista.Add(objMonedas);
                }
                var monedaEvaluar = lista.FirstOrDefault(e => e.IdMoneda == transaccion.MonedaId);
                if (monedaEvaluar != null && monedaEvaluar.Saldo > transaccion.Cantidad && double.TryParse(transaccion.Cantidad.ToString(), out double numero))
                {
                    var nuevaTransaccion = new Transaccion
                    {
                       Cantidad = cantidadNegativa,
                       Cotizacion = transaccion.Cotizacion,
                       Fecha = fechaLocal,
                       MonedaId = transaccion.MonedaId,
                       Operacion = transaccion.Operacion,
                    };
                    _context.Transacciones.Add(nuevaTransaccion);
                    _context.SaveChanges();
                    return Ok(nuevaTransaccion);
                }
                else
                    return BadRequest(new { mensaje = "datos ingresados incorrectos" });
            }
        }


    }
}
