﻿namespace practicoFinal_Programacion3.Models
{
    public class ViewModelMonedas
    {
        public int IdMoneda { get; set; }
        public string MonedaNombre { get; set; }
        public double Saldo { get; set; }
        public double SaldoTotalPesos { get; set; }
    }
}
