﻿namespace practicoFinal_Programacion3.Models
{
    public class Transaccion
    {
        public int Id { get; set; }
        public int MonedaId { get; set; }
        public DateTimeOffset Fecha {  get; set; }
        public double Cantidad { get; set; }
        public double Cotizacion { get; set; }
        public Moneda? moneda { get; set; }

        public string Operacion { get; set; }
    }
}
