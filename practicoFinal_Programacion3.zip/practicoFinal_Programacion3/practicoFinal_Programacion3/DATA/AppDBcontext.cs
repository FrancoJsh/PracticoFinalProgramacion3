﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using practicoFinal_Programacion3.Models;

namespace practicoFinal_Programacion3.DATA
{
    public class AppDBcontext : DbContext
    {
        public AppDBcontext(DbContextOptions options) : base(options) { }
        
        public DbSet<Moneda> Monedas {  get; set; }
        public DbSet<Transaccion> Transacciones { get; set; }

    }
}
