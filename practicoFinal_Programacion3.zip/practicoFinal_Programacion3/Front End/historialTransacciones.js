async function ObtenerHistorial(){
    try {
      const response = await fetch('https://localhost:7022/api/ListarTransacciones');
      if(!response.ok){
        throw new Error('Error en la solicitud: '+ response.status);
      }
      const data = await response.json();
      console.log('datos recibidos:', data);
      
      ArmarTabla(data);
      
    } catch (error) {
        (error => {
          console.log('error de datos:', error)
        })
    }
  }

function ArmarTabla(transacciones) {
  const tabla = document.getElementById('tablaHistorial');
  tabla.innerHTML = "";

  if (!transacciones.length) {
    tabla.innerHTML = `
      <tr>
        <td colspan="6" class="p-4 text-center text-gray-500 italic">No hay transacciones registradas</td>
      </tr>
    `;
    return;
  }
console.log('llega?', transacciones);
  transacciones.forEach(item => {
    const fila = `
      <tr class="border-t hover:bg-gray-50">
        <td class="p-3 text-left font-medium text-gray-700">${item.nombre}</td>
        <td class="p-3 text-center text-gray-700">${item.cantidad}</td>
        <td class="p-3 text-center text-gray-700">$${item.cotizacion.toFixed(2)}</td>
        <td class="p-3 text-left text-gray-700">${new Date(item.fecha).toLocaleString()}</td>
        <td class="p-3 text-center text-gray-700">$${item.montoTotal.toFixed(2)}</td>
        <td class="p-3 text-center text-gray-700 capitalize">${item.operacion}</td>
      </tr>
    `;
    tabla.innerHTML += fila;
  });
}

function CerrarSesion(){
const usuarioGuardado = localStorage.getItem('usuario');
const usuario = JSON.parse(usuarioGuardado);
if(usuario != null){
  localStorage.removeItem("usuario");
}
window.location.href = "index.html";
}