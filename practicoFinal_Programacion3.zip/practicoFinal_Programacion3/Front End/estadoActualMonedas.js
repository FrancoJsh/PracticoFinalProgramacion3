async function ObtenerMonedasActualizadas(){
    try {
      const response = await fetch('https://localhost:7022/api/EstadoActual');
      if(!response.ok){
        throw new Error('Error en la solicitud: '+ response.status);
      }
      const data = await response.json();
      console.log('datos recibidos:', data);
      
      ArmarTabla(data);
      
    } catch (error) {
        (error => {
          console.log('error de datos:', error)
        })
    }
}

function ArmarTabla(movimientos) {
  const tabla = document.getElementById('tablaMovimientos');
  tabla.innerHTML = "";

  if (!movimientos.length) {
    tabla.innerHTML = `
      <tr>
        <td colspan="6" class="p-4 text-center text-gray-500 italic">No hay movimientos realizados</td>
      </tr>
    `;
    return;
  }

let saldoTotalPesos = 0;
movimientos.forEach((item, index) => {
  const filaSaldo = `
    <tr class="hover:bg-gray-50">
      <td class="p-3 text-left font-medium text-gray-800">${item.monedaNombre}</td>
      <td class="p-3 text-left text-gray-800">${item.saldo.toFixed(2)}</td>
    </tr>
  `;
  tabla.innerHTML += filaSaldo;
  if (index === 0 && item.saldoTotalPesos) {
    saldoTotalPesos = item.saldoTotalPesos;
  }
});
const filaTotal = `
  <tr class="bg-gray-50">
    <td class="p-3 text-left italic text-gray-600 pl-8">Total</td>
    <td class="p-3 text-left font-semibold text-gray-900">$${saldoTotalPesos.toFixed(2)}</td>
  </tr>
`;

tabla.innerHTML += filaTotal;
}

function CerrarSesion(){
const usuarioGuardado = localStorage.getItem('usuario');
const usuario = JSON.parse(usuarioGuardado);
if(usuario != null){
  localStorage.removeItem("usuario");
}
window.location.href = "index.html";
}