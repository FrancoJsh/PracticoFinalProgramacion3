function RegistroUsuario(event){
event.preventDefault();
const datosUsuario = {
    email : document.getElementById("emailUsuario").value,
    nombre : document.getElementById("nombreUsuario").value,
    saldo : document.getElementById("saldoUsuario").value,
};
 const esValido = ValidarRegistro(datosUsuario);
if(!esValido)
    return;
GuardarRegistro(datosUsuario);
document.getElementById("formularioRegistro").reset();
}

function ValidarRegistro(datosUsuario){
    let esValido = true;
    
    const errorNombre = document.getElementById("errorNombre");
    const errorEmail = document.getElementById("errorEmail");
    const errorSaldo = document.getElementById("errorSaldo");
    errorNombre.textContent = "";
    errorEmail.textContent = "";
    errorSaldo.textContent = "";


if(datosUsuario.email.trim() === "" || !datosUsuario.email.includes("@")){
    errorEmail.textContent = "Ingrese un correo válido";
    esValido = false;
}
if(datosUsuario.nombre.trim() === ""){
    errorNombre.textContent = "Ingrese un nombre válido";
    esValido = false;
}
const saldo = parseFloat(datosUsuario.saldo);
if(isNaN(saldo) || saldo <= 0){
    errorSaldo.textContent = "Ingrese un saldo correcto";
    esValido = false;
}
return esValido;
}

function GuardarRegistro(datosUsuario){
    localStorage.setItem("usuario", JSON.stringify(datosUsuario));
    console.log("Contenido en localStorage:", localStorage.getItem("usuario"));
}

function cerrarFormulario(){
   const formulario = document.getElementById("registroModal");
   const usuario = localStorage.getItem('usuario');
   if(!usuario){
    formulario.style.display = "block";
    alert("Ingrese un usuario");
   }
   else{
     registroModal.style.display = 'none';
   }
}


function mostrarFormulario(){
  const usuarioPosible = localStorage.getItem('usuario');
  if(!usuarioPosible){
      registroModal.style.display = 'block';
  }else{
      registroModal.style.display = 'none';
  }
  }

  window.onload = mostrarFormulario;
  
  function cerrarSesion() {
      localStorage.removeItem('usuario');
      validarUsuario();
    }
