async function obtenerCotizaciones() {
  const select = document.getElementById("selectMonedas");
  console.log(select);
    try {
      const textoSeleccionado = select.options[select.selectedIndex].text;
      console.log(textoSeleccionado);
      const url = `https://criptoya.com/api/${textoSeleccionado}/ARS/0.1`;
      const tipo = select.dataset.tipo;

      const respuesta = await fetch(url);
      const datos = await respuesta.json();
      if(tipo === "compra"){
        const ordenado = Object.entries(datos)
          .map(([exchange, valores]) => ({
            exchange,
            ask: valores.ask,
            bid: valores.bid
          }))
          .sort((a, b) => a.ask - b.ask);
      const tabla = document.getElementById('tabla-body');
      tabla.innerHTML = '';
  
      ordenado.forEach(item => {
        const fila = `
            <tr class="even:bg-gray-700 hover:bg-gray-600 transition">
              <td class="px-4 py-2 text-white">${item.exchange}</td>
              <td class="px-4 py-2 text-white">$${item.bid.toFixed(2)}</td>
              <td class="px-4 py-2 text-white">$${item.ask.toFixed(2)}</td>
            </tr>
          `;
      tabla.innerHTML += fila;
      }); 
      }else{
        const ordenado = Object.entries(datos)
        .map(([exchange, valores]) => ({
          exchange,
          ask: parseFloat(valores.ask),
          bid: parseFloat(valores.bid)
        }))
        .sort((a, b) => b.bid - a.bid);

      const tabla = document.getElementById('tabla-body');
      tabla.innerHTML = '';

      ordenado.forEach(item => {
        const fila = `
          <tr>
            <td class="border border-gray-300">${item.exchange}</td>
            <td class="border border-gray-300">$${item.bid.toFixed(2)}</td>
            <td class="border border-gray-300">$${item.ask.toFixed(2)}</td>
          </tr>
        `;
        tabla.innerHTML += fila;
      });
      }
    } catch (error) {
      console.error('Error al cargar cotizaciones:', error);
    }
}

async function CargarSelect() {
  const select = document.getElementById("selectMonedas");
  fetch("https://localhost:7022/api/ListarMonedas")
  .then(response => {
    if (!response.ok) {
      throw new Error("Error al obtener monedas");
    }
    return response.json();
  })
  .then(data => {
    console.log("Monedas:", data);
    data.forEach(moneda => {
      const opcion = document.createElement("option");
      opcion.value = moneda.id;
      opcion.textContent = moneda.abreviatura;
      select.appendChild(opcion);
    });
    obtenerCotizaciones();
    select.addEventListener("change", obtenerCotizaciones);
  })
  .catch(error => {
    console.error("Error en fetch:", error);
  });
}

CargarSelect();

async function GuardarTransaccionCompra(){
      const usuarioGuardado = localStorage.getItem('usuario');
      const usuario = JSON.parse(usuarioGuardado);
      const exchangeEvaluar = document.getElementById("ExchangeCompra").value;
      const cantidadEvaluar = document.getElementById('cantidadCompra').value;
      const exchange = exchangeEvaluar.toLowerCase();
      const errorExchange = document.getElementById("ErrorExchangeCompra");
      const errorCantidadCompra = document.getElementById("errorCantidadCompra");
      const errorCotizacion = document.getElementById("errorCotizacionesCompra");
      errorExchange.textContent = "";
      errorCantidadCompra.textContent = "";
      errorCotizacion.textContent = "";

      let hayError = false;

      if(exchange.trim() === ""){
        errorExchange.textContent = "Ingrese un exchange válido"
        hayError = true;
      }
      const Operacion = "compra";
      const cotizacion = await obtenerCotizacionEspecifica(exchange, Operacion);
      if (!cotizacion) {
        errorCotizacion.textContent = "No se pudo obtener la cotización";
        hayError = true;
      }
      const cantidad = parseFloat(cantidadEvaluar);
      if(cantidad <= 0 || isNaN(cantidad) || usuario.saldo < cantidad){
        errorCantidadCompra.textContent = "Ingrese un monto válido de compra";
        hayError = true;
      }
      if(hayError){
        return;
      }

      const transaccion = {
        MonedaId: parseInt(document.getElementById('selectMonedas').value),
        Fecha: new Date().toISOString(),
        Cantidad: cantidad,
        Cotizacion: cotizacion,
        Operacion: "Compra",
      };
      fetch('https://localhost:7022/api/CrearTransaction', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json' 
      },
      body: JSON.stringify(transaccion)
    })
    .then(res => res.json())
    .then(data => console.log(data));
    exchangeValue.value = "";
    cantidadPrimera.value = "";
  }

async function GuardarTransaccionVenta(){
  const cantidadVentaEvaluar = document.getElementById('cantidadVenta').value;
  const exchangeValue = document.getElementById("ExchangeVenta").value;
  const errorCantidadVenta = document.getElementById('errorCantidadVenta');
  const errorExchange = document.getElementById("errorExchangeVenta");
  const errorCotizaciones = document.getElementById("errorCotizaciones");
  const exchange = exchangeValue.toLowerCase();

  errorExchange.textContent = "";
  errorCantidadVenta.textContent = "";

  let hayError = false;

  if(exchangeValue.trim() === ""){
    errorExchange.textContent = "Ingrese un exchange válido";
    hayError = true;
  }
  const cantidadVenta = parseFloat(cantidadVentaEvaluar);
  if(cantidadVenta <= 0 || isNaN(cantidadVenta)){
    errorCantidadVenta.textContent = "Ingrese una cantidad válida";
    hayError = true;
  }
  const Operacion = "venta";
  const cotizacion = await obtenerCotizacionEspecifica(exchange, Operacion);
  if (!cotizacion) {
      errorCotizaciones.textContent = "No se pudo obtener la cotización";
      hayError = true;
  }
  if(hayError){
    return;
  }
 
     const transaccion = {
        MonedaId: parseInt(document.getElementById('selectMonedas').value),
        Fecha: new Date().toISOString(),
        Cantidad: cantidadVenta,
        Cotizacion: cotizacion,
        Operacion: "venta",
      };
      fetch('https://localhost:7022/api/CrearTransaction', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json' 
      },
      body: JSON.stringify(transaccion)
    })
    .then(res => res.json())
    .then(data => console.log(data));

    cantidadVentaEvaluar.value = "";
    exchangeValue.value = "";
}

async function obtenerCotizacionEspecifica(exchange, Operacion){
const select = document.getElementById('selectMonedas');
const moneda = select.options[select.selectedIndex].text;
const url = `https://criptoya.com/api/${exchange}/${moneda}/ARS/0.1`
const respuesta = await fetch(url);
const datos = await respuesta.json();
if(Operacion === "compra"){
const precioAsk = datos.ask;
return precioAsk;
}else{
  const precioBid = datos.bid;
  return precioBid;
}
}

function CerrarSesion(){
const usuarioGuardado = localStorage.getItem('usuario');
const usuario = JSON.parse(usuarioGuardado);
if(usuario != null){
  localStorage.removeItem("usuario");
}
window.location.href = "index.html";
}


